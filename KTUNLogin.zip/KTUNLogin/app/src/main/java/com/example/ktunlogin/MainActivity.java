package com.example.ktunlogin;

import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        final ImageView img=findViewById(R.id.img);
        final Button btn=(Button) findViewById(R.id.btn);
        final EditText text1=findViewById(R.id.text1);
        final EditText text2=findViewById(R.id.text2);
        final ImageView img1=(ImageView) findViewById(R.id.img1);


        new Handler().postDelayed(new Runnable() {

            @Override
            public void run() {
                img.setVisibility(View.GONE);
                img1.setVisibility(View.VISIBLE);
                text1.setVisibility(View.VISIBLE);
                text2.setVisibility(View.VISIBLE);
                btn.setVisibility(View.VISIBLE);

            }
        }, 5000 );





        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity.this,"Giriş Yapılıyor...",Toast.LENGTH_LONG).show();
            }
        });
    }
}
